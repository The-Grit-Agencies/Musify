module.exports = {
  plugins: [
    require('tailwindcss'),
    require('autoprefixer'),
    // Add more plugins as needed
  ],
};
