// tailwind.config.js
module.exports = {
  purge: ['./templates/**/*.html', './static/**/*.css'],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {},
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
